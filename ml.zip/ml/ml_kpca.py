import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Step 1: Import dataset
dataset = pd.read_csv('hybrid_manufacturing_categorical.csv')
X = dataset.iloc[:, :-1]
y = dfrom sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
ataset.iloc[:, -1].values

# Step 2: Identify categorical columns
categorical_columns = X.select_dtypes(include=['object']).columns.tolist()
numerical_columns = [col for col in X.columns if col not in categorical_columns]

# Step 3: Preprocessing - Encode categoricals, scale numericals

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_columns),
        ('num', StandardScaler(), numerical_columns)
    ])

# Step 4: Train-test split
from sklearn.model_selection import train_test_split
X_train_raw, X_test_raw, y_train, y_test = train_test_split(X, y, test_size=0.40, random_state=0)

# Step 5: Apply preprocessing
X_train = preprocessor.fit_transform(X_train_raw)
X_test = preprocessor.transform(X_test_raw)

# Step 6: Apply Kernel PCA
from sklearn.decomposition import KernelPCA
kernel_pca = KernelPCA(n_components=10, kernel='linear', gamma=0.03)
X_train = kernel_pca.fit_transform(X_train)
X_test = kernel_pca.transform(X_test)

# Step 7: Train Decision Tree Classifier
from sklearn.tree import DecisionTreeClassifier
classifier = DecisionTreeClassifier(criterion='entropy', random_state=0)
classifier.fit(X_train, y_train)

# Step 8: Predict test results
y_pred = classifier.predict(X_test)
print(np.concatenate((y_pred.reshape(-1,1), y_test.reshape(-1,1)), axis=1))

# Step 9: Confusion matrix & accuracy
from sklearn.metrics import confusion_matrix, accuracy_score
cm = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:\n", cm)
print("Accuracy Score:", accuracy_score(y_test, y_pred))

